﻿# MADMAX Messenger

## Структура
- app ( основной код)

## Запуск
- Установить зависимости: `pip install -r requirements.txt`
- Указать ключ комнаты в `MADMAX_PSK`
- Запустить - `python -m app.main`
- Проверить окружение - `python -m app.tools.health_check`

