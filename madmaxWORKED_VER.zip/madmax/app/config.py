import os
from pathlib import Path
from typing import Optional

APP_DIR = Path(__file__).resolve().parent
BASE_DIR = APP_DIR.parent

# Paths
DOWNLOAD_DIR = BASE_DIR / "downloads"
DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = BASE_DIR / "chat.db"
META_DIR = BASE_DIR / ".meta"

# Network&protocol
PROTOCOL_VERSION = 1
MAX_HEADER_SIZE = 1024 * 64
MAX_PAYLOAD_SIZE = 1024 * 1024 * 100
NONCE_SIZE_BYTES = 16
SOCKET_TIMEOUT = 30.0
MAX_BACKLOG_CONNECTIONS = 8
MAX_CLIENTS = 16


def load_psk(override: Optional[str] = None) -> bytes:
    secret = override if override is not None else os.getenv("MADMAX_PSK", "")
    return secret.encode("utf-8")
