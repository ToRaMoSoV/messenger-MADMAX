import hashlib
import hmac
import json
import os
from datetime import date
from pathlib import Path
from typing import Optional

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

from app import config

AUTO_KEY_FILE = "db_key_auto.bin"
AUTO_META = "day_key.json"
AES_BLOCK_SIZE = 16
MAC_SIZE = 32


def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def _hmac(key: bytes, payload: bytes) -> bytes:
    return hmac.new(key, payload, hashlib.sha256).digest()


def _load_auto_key() -> bytes:
    config.META_DIR.mkdir(parents=True, exist_ok=True)
    meta_path = config.META_DIR / AUTO_META
    key_path = config.META_DIR / AUTO_KEY_FILE
    today = date.today().isoformat()
    meta = {}
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            meta = {}
    if meta.get("day") != today or not key_path.exists():
        key = os.urandom(32)
        key_path.write_bytes(key)
        meta_path.write_text(json.dumps({"day": today}), encoding="utf-8")
    return key_path.read_bytes()


def _key_from_password(password: Optional[str]) -> bytes:
    if not password:
        return _load_auto_key()
    return sha256(password.encode("utf-8"))


def encrypt_db(password: Optional[str], out_ext: str = ".enc") -> str:
    if not config.DB_PATH.exists():
        raise FileNotFoundError(f"Database file not found: {config.DB_PATH}")

    key = _key_from_password(password)
    iv = os.urandom(AES_BLOCK_SIZE)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).encryptor()
    plain = config.DB_PATH.read_bytes()

    pad_len = AES_BLOCK_SIZE - (len(plain) % AES_BLOCK_SIZE)
    plain_padded = plain + bytes([pad_len]) * pad_len
    ct = cipher.update(plain_padded) + cipher.finalize()
    mac = _hmac(key, iv + ct)

    out_path = config.DB_PATH.with_suffix(config.DB_PATH.suffix + out_ext)
    out_path.write_bytes(iv + ct + mac)
    return str(out_path)


def decrypt_db(password: Optional[str], enc_path: str, restore_as: str = "chat.db") -> str:
    enc_file = Path(enc_path)
    if not enc_file.exists():
        raise FileNotFoundError(f"Encrypted file not found: {enc_path}")

    key = _key_from_password(password)
    blob = enc_file.read_bytes()

    if len(blob) < AES_BLOCK_SIZE + MAC_SIZE:
        raise ValueError("Encrypted file too small (missing IV/HMAC)")

    iv = blob[:AES_BLOCK_SIZE]
    ct = blob[AES_BLOCK_SIZE:-MAC_SIZE]
    mac = blob[-MAC_SIZE:]

    expected_mac = _hmac(key, iv + ct)
    if not hmac.compare_digest(mac, expected_mac):
        raise ValueError("HMAC check failed (corrupted file or wrong password)")

    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend()).decryptor()
    plain_padded = decryptor.update(ct) + decryptor.finalize()

    if len(plain_padded) < 1:
        raise ValueError("Decrypted data is empty")

    pad_len = plain_padded[-1]
    if pad_len < 1 or pad_len > AES_BLOCK_SIZE:
        raise ValueError("Bad padding")
    if not all(b == pad_len for b in plain_padded[-pad_len:]):
        raise ValueError("Invalid padding bytes")

    plain = plain_padded[:-pad_len]
    out_path = Path(restore_as)
    out_path.write_bytes(plain)
    return str(out_path)
