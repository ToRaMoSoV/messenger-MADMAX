import sqlite3
import time
from typing import List, Tuple

from app import config

DB_TIMEOUT = 5.0


def _conn():
    """Создаёт соединение SQLite, привязанное к корню проекта."""
    return sqlite3.connect(config.DB_PATH, timeout=DB_TIMEOUT, check_same_thread=False)


def init_db():
    """Создаёт таблицы, если их ещё нет."""
    with _conn() as con:
        con.execute(
            """CREATE TABLE IF NOT EXISTS contacts(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                ip TEXT,
                port INTEGER
            )"""
        )
        con.execute(
            """CREATE TABLE IF NOT EXISTS messages(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                peer TEXT,
                direction TEXT,
                content TEXT,
                ts REAL
            )"""
        )


def add_contact(name: str, ip: str, port: int):
    """Сохраняет новый контакт."""
    with _conn() as con:
        con.execute('INSERT INTO contacts(name, ip, port) VALUES(?,?,?)', (name, ip, port))


def list_contacts() -> List[Tuple[int, str, str, int]]:
    """Возвращает контакты, отсортированные по убыванию id."""
    with _conn() as con:
        cur = con.cursor()
        cur.execute('SELECT id, name, ip, port FROM contacts ORDER BY id DESC')
        rows = cur.fetchall()
    return rows


def add_message(peer: str, direction: str, content: str):
    """Сохраняет сообщение с меткой времени."""
    with _conn() as con:
        con.execute('INSERT INTO messages(peer, direction, content, ts) VALUES(?,?,?,?)',
                    (peer, direction, content, time.time()))


def last_messages(limit: int = 100) -> List[Tuple[int, str, str, str, float]]:
    """Возвращает последние сообщения (сначала новые)."""
    with _conn() as con:
        cur = con.cursor()
        cur.execute('SELECT id, peer, direction, content, ts FROM messages ORDER BY id DESC LIMIT ?', (limit,))
        rows = cur.fetchall()
    return rows
