import os
import socket
import struct
import json
import threading
import hashlib
import re
from pathlib import Path
from typing import Callable, Optional, Dict, Tuple, List

from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms

from app import config


def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def chacha20_encrypt(key: bytes, plaintext: bytes, nonce: bytes) -> bytes:
    cipher = Cipher(algorithms.ChaCha20(key, nonce), mode=None)
    return cipher.encryptor().update(plaintext)


def chacha20_decrypt(key: bytes, ciphertext: bytes, nonce: bytes) -> bytes:
    cipher = Cipher(algorithms.ChaCha20(key, nonce), mode=None)
    return cipher.decryptor().update(ciphertext)


def get_local_ip() -> str:
    """Узнаёт локальный IPv4"""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.settimeout(1.0)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip


def _sanitize_filename(filename: str) -> str:
    """Грубая чистка имени файла"""
    safe = os.path.basename(filename)
    safe = safe.replace("..", "")
    safe = safe.replace("/", "_")
    safe = safe.replace("\\", "_")
    safe = re.sub(r'[<>:"|?*]', '_', safe)
    if len(safe) > 255:
        name, ext = os.path.splitext(safe)
        safe = name[:255 - len(ext)] + ext
    return safe or "received_file.bin"


def _save_file_safely(data: bytes, filename: str, prefix: str = "") -> Path:
    """Сохраняем в downloads, подбираем имя"""
    safe_name = _sanitize_filename(filename)
    if prefix:
        safe_name = f"{prefix}_{safe_name}"

    save_path = config.DOWNLOAD_DIR / safe_name

    counter = 1
    base_name = save_path.stem
    suffix = save_path.suffix
    while save_path.exists():
        save_path = config.DOWNLOAD_DIR / f"{base_name}_{counter}{suffix}"
        counter += 1

    save_path.write_bytes(data)
    return save_path


def validate_ip(ip: str) -> bool:
    """Проверка IPv4"""
    try:
        parts = ip.split('.')
        if len(parts) != 4:
            return False
        for part in parts:
            num = int(part)
            if num < 0 or num > 255:
                return False
        return True
    except (ValueError, AttributeError):
        return False


def validate_port(port: int) -> bool:
    """Валидация порта"""
    return isinstance(port, int) and 1 <= port <= 65535


class PeerNode:
    """P2P-узел - X25519 для рукопожатия, ChaCha20+MAC для данных.

    TODO: анти-replay по nonce/seq; crypto пока здесь - вынести и перейти на AEAD.
    TODO: KDF для PSK/ключей, а не сырой SHA-256.
    """

    def __init__(self, pre_shared_secret: Optional[str] = None):
        self.on_log: Callable[[str], None] = lambda m: None
        self.on_message: Callable[[str, str], None] = lambda sender, m: None
        self.on_file_saved: Callable[[str], None] = lambda p: None
        self.on_state: Callable[[str], None] = lambda s: None
        self.on_members: Callable[[List[str]], None] = lambda members: None

        self.my_name: str = "Me"
        self.room_name: str = "Room"

        self._priv = x25519.X25519PrivateKey.generate()
        self._pub = self._priv.public_key()

        self.conn: Optional[socket.socket] = None
        self.shared_key: Optional[bytes] = None

        self.server_sock: Optional[socket.socket] = None
        self.host_addr: Optional[Tuple[str, int]] = None
        self.clients: Dict[socket.socket, Dict] = {}
        self._clients_lock = threading.RLock()

        self._srv_thread: Optional[threading.Thread] = None
        self._stop = threading.Event()

        self._psk = config.load_psk(pre_shared_secret)

    def _reset_stop_flag(self):
        if self._stop.is_set():
            self._stop.clear()

    def _auth_tag(self, key: bytes) -> bytes:
        return sha256(key + self._psk)

    def _aad_for_header(self, hdr: dict) -> bytes:
        parts = [
            str(hdr.get("v", config.PROTOCOL_VERSION)),
            str(hdr.get("type", "")),
            str(hdr.get("sender", "")),
            str(hdr.get("filename", "")),
            str(hdr.get("content_len", "")),
            str(hdr.get("nonce_hex", "")),
        ]
        return "|".join(parts).encode("utf-8")

    def _mac(self, key: bytes, nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes:
        return sha256(aad + nonce + ciphertext + sha256(key) + self._psk)

    def _send_packet(self, sock: socket.socket, header: dict, payload: bytes = b""):
        header = dict(header)
        header.setdefault("v", config.PROTOCOL_VERSION)
        hdr = json.dumps(header).encode("utf-8")
        sock.sendall(struct.pack(">I", len(hdr)) + hdr + payload)

    def _recv_exact(self, sock: socket.socket, n: int, timeout: float = config.SOCKET_TIMEOUT) -> bytes:
        sock.settimeout(timeout)
        buf = b""
        while len(buf) < n:
            chunk = sock.recv(n - len(buf))
            if not chunk:
                raise ConnectionError("Socket closed")
            buf += chunk
        return buf

    def _recv_packet(self, sock: socket.socket):
        raw = self._recv_exact(sock, 4)
        (hdr_len,) = struct.unpack(">I", raw)

        if hdr_len > config.MAX_HEADER_SIZE:
            raise ValueError(f"Header too large: {hdr_len} bytes (max: {config.MAX_HEADER_SIZE})")

        hdr_data = self._recv_exact(sock, hdr_len)
        hdr = json.loads(hdr_data.decode("utf-8"))

        payload = b""
        try:
            content_len = int(hdr.get("content_len", 0) or 0)
        except (TypeError, ValueError):
            raise ValueError("Invalid content length in header")
        if content_len < 0:
            raise ValueError("Payload length cannot be negative")
        if content_len > 0:
            if content_len > config.MAX_PAYLOAD_SIZE:
                raise ValueError(f"Payload too large: {content_len} bytes (max: {config.MAX_PAYLOAD_SIZE})")
            payload = self._recv_exact(sock, content_len)

        return hdr, payload

    def _encrypt_with(self, key: bytes, plaintext: bytes, header_fields: dict):
        nonce = os.urandom(config.NONCE_SIZE_BYTES)
        cipher = chacha20_encrypt(key, plaintext, nonce)
        header_fields = dict(header_fields)
        header_fields["nonce_hex"] = nonce.hex()
        header_fields["content_len"] = len(cipher)
        aad = self._aad_for_header(header_fields)
        digest = self._mac(key, nonce, cipher, aad)
        return nonce, cipher, digest

    def _decrypt_with(self, key: bytes, nonce: bytes, ciphertext: bytes, digest: bytes, header_fields: dict) -> bytes:
        aad = self._aad_for_header(header_fields)
        check = self._mac(key, nonce, ciphertext, aad)
        if check != digest:
            raise ValueError("Integrity check failed (SHA-256 mismatch)")
        return chacha20_decrypt(key, ciphertext, nonce)

    def connect_to(self, ip: str, port: int, timeout: float = 5.0):
        if not validate_ip(ip):
            raise ValueError(f"Invalid IP address: {ip}")
        if not validate_port(port):
            raise ValueError(f"Invalid port: {port}")

        self._reset_stop_flag()

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((ip, port))
        self.conn = s
        self.on_log(f"Connected to {ip}:{port}")
        self.on_state(f"CONNECTED {ip}:{port}")

        my_pub = self._pub.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        self._send_packet(self.conn, {"type": "key", "content_len": len(my_pub)}, my_pub)

        hdr, payload = self._recv_packet(self.conn)
        if hdr.get("type") != "key":
            raise RuntimeError("Handshake failed: expected key")
        peer_pub = x25519.X25519PublicKey.from_public_bytes(payload)
        shared = self._priv.exchange(peer_pub)
        self.shared_key = sha256(shared)

        hello_body = json.dumps({"name": self.my_name}).encode("utf-8")
        base_header = {
            "type": "hello",
            "auth_hex": self._auth_tag(self.shared_key).hex(),
            "v": config.PROTOCOL_VERSION
            }
        nonce, cipher, digest = self._encrypt_with(self.shared_key, hello_body, base_header)
        header = {
            "type": "hello",
            "v": config.PROTOCOL_VERSION,
            "auth_hex": self._auth_tag(self.shared_key).hex(),
            "nonce_hex": nonce.hex(),
            "digest_hex": digest.hex(),
            "content_len": len(cipher),
        }
        self._send_packet(self.conn, header, cipher)

        threading.Thread(target=self._client_rx_loop, daemon=True).start()

    def _client_rx_loop(self):
        conn = self.conn
        if conn is None:
            self.on_log("Client rx loop started without an active socket")
            return
        try:
            while not self._stop.is_set():
                hdr, payload = self._recv_packet(conn)
                if hdr.get("v", config.PROTOCOL_VERSION) != config.PROTOCOL_VERSION:
                    self.on_log(f"Protocol version mismatch: {hdr.get('v')}")
                    continue
                t = hdr.get("type")

                if t == "msg":
                    key = self.shared_key
                    if key is None:
                        raise RuntimeError("Shared key not established")
                    nonce = bytes.fromhex(hdr["nonce_hex"])
                    digest = bytes.fromhex(hdr["digest_hex"])
                    plain = self._decrypt_with(key, nonce, payload, digest, hdr)
                    sender = hdr.get("sender", "peer")
                    try:
                        text = plain.decode("utf-8")
                    except UnicodeDecodeError as e:
                        self.on_log(f"Decode error: {e!r}, raw: {plain[:100]!r}")
                        text = plain.decode("utf-8", errors="replace")
                    self.on_message(sender, text)

                elif t == "file":
                    key = self.shared_key
                    if key is None:
                        raise RuntimeError("shared key not established")
                    nonce = bytes.fromhex(hdr["nonce_hex"])
                    digest = bytes.fromhex(hdr["digest_hex"])
                    data = self._decrypt_with(key, nonce, payload, digest, hdr)
                    fname = hdr.get("filename", "received.bin")
                    save_path = _save_file_safely(data, fname, prefix="received")
                    self.on_file_saved(str(save_path))
                    self.on_log(f"Client received file: {fname}, saved to {save_path}")

                elif t == "members":
                    key = self.shared_key
                    if key is None:
                        raise RuntimeError("shared key not established")
                    nonce = bytes.fromhex(hdr["nonce_hex"])
                    digest = bytes.fromhex(hdr["digest_hex"])
                    data = self._decrypt_with(key, nonce, payload, digest, hdr)
                    try:
                        members = json.loads(data.decode("utf-8"))
                        self.on_members(members)
                    except Exception as e:
                        self.on_log(f"members parse error: {e!r}")

                elif t == "key":
                    self.on_log("extra key ignored (client).")

                else:
                    self.on_log(f"unknown packet: {t}")

        except Exception as e:
            self.on_log(f"Client RX error: {e!r}")
        finally:
            try:
                if conn:
                    conn.close()
            except Exception as close_err:
                self.on_log(f"Error closing client connection: {close_err!r}")
            self.conn = None
            self.shared_key = None
            self.on_state("DISCONNECTED")

    def send_text(self, text: str):
        if self.conn and self.shared_key:
            try:
                base_header = {"type": "msg", "sender": self.my_name}
                nonce, c, d = self._encrypt_with(self.shared_key, text.encode("utf-8"), base_header)
                hdr = {
                    "type": "msg",
                    "sender": self.my_name,
                    "nonce_hex": nonce.hex(),
                    "digest_hex": d.hex(),
                    "content_len": len(c),
                }
                self._send_packet(self.conn, hdr, c)
                self.on_log(f"Client send_text ok: {len(c)} bytes")
            except Exception as e:
                self.on_log(f"Client send_text error: {e!r}")
            return

        if self.server_sock:
            with self._clients_lock:
                has_clients = len(self.clients) > 0
                if has_clients:
                    clients_copy = list(self.clients.items())

            if has_clients:
                plaintext = text.encode("utf-8")
                sender = f"{self.host_addr[0]}:{self.host_addr[1]} Host" if self.host_addr else "Host"
                sent = 0
                for s, inf in clients_copy:
                    try:
                        key = inf["key"]
                        base_header = {"type": "msg", "sender": sender}
                        n, c, d = self._encrypt_with(key, plaintext, base_header)
                        hdr = {
                            "type": "msg",
                            "sender": sender,
                            "nonce_hex": n.hex(),
                            "digest_hex": d.hex(),
                            "content_len": len(c),
                        }
                        self._send_packet(s, hdr, c)
                        sent += 1
                    except Exception as e:
                        self.on_log(f"Host send_text to {inf.get('display', inf.get('addr'))} failed: {e!r}")
                self.on_log(f"Host send_text broadcast: {sent} clients")
                self.on_message(sender, text)
                return

        self.on_log("send_text: Not connected (no peer / no room clients)")

    def send_file(self, path: str):
        if not os.path.isfile(path):
            self.on_log(f"send_file: not a file: {path}")
            return

        try:
            with open(path, "rb") as f:
                data = f.read()
            size = len(data)
        except Exception as e:
            self.on_log(f"send_file: read error: {e!r}")
            return

        filename = os.path.basename(path)

        if self.conn and self.shared_key:
            try:
                base_header = {"type": "file", "sender": self.my_name, "filename": filename}
                nonce, cipher, digest = self._encrypt_with(self.shared_key, data, base_header)
                hdr = {
                    "type": "file",
                    "sender": self.my_name,
                    "filename": filename,
                    "nonce_hex": nonce.hex(),
                    "digest_hex": digest.hex(),
                    "content_len": len(cipher),
                }
                self._send_packet(self.conn, hdr, cipher)
                self.on_log(f"Client send_file ok: {filename} ({size} bytes)")
            except Exception as e:
                self.on_log(f"Client send_file error: {e!r}")
            return

        if self.server_sock:
            with self._clients_lock:
                has_clients = len(self.clients) > 0
                if has_clients:
                    clients_copy = list(self.clients.items())

            if has_clients:
                sender = f"{self.host_addr[0]}:{self.host_addr[1]} Host" if self.host_addr else "Host"

                try:
                    save_path = _save_file_safely(data, filename, prefix="host_received")
                    self.on_log(f"Host saved copy: {save_path} ({size} bytes)")
                except Exception as e:
                    self.on_log(f"Host save copy error: {e!r}")

                sent = 0
                for s, inf in clients_copy:
                    try:
                        key = inf["key"]
                        base_header = {"type": "file", "sender": sender, "filename": filename}
                        n, c, d = self._encrypt_with(key, data, base_header)
                        hdr = {
                            "type": "file",
                            "sender": sender,
                            "filename": filename,
                            "nonce_hex": n.hex(),
                            "digest_hex": d.hex(),
                            "content_len": len(c),
                        }
                        self._send_packet(s, hdr, c)
                        sent += 1
                    except Exception as e:
                        self.on_log(f"Host send_file to {inf.get('display', inf.get('addr'))} failed: {e!r}")

                self.on_log(f"Host send_file broadcast: {filename}, size={size} bytes, clients={sent}")
                self.on_message(sender, f"[file sent: {filename}]")
                return

        self.on_log("send_file: Not connected (no peer / no room clients)")

    def start_host(self, host_ip: str = "0.0.0.0", port: int = 0):
        self._reset_stop_flag()
        self.server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_sock.bind((host_ip, port))
        self.server_sock.listen(config.MAX_BACKLOG_CONNECTIONS)
        self.server_sock.settimeout(1.0)
        real_ip = get_local_ip() if host_ip =="0.0.0.0" else host_ip
        real_port = self.server_sock.getsockname()[1]
        self.host_addr = (real_ip, real_port)
        self.on_log(f"Host listening on {real_ip}:{real_port}")
        self.on_state(f"LISTEN {real_ip}:{real_port}")
        self._srv_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._srv_thread.start()
        self._notify_members_to_ui()
        return real_ip, real_port

    def _accept_loop(self):
        try:
            while not self._stop.is_set():
                if self.server_sock is None:
                    break
                try:
                    sock, addr = self.server_sock.accept()
                except socket.timeout:
                    continue
                with self._clients_lock:
                    if len(self.clients) >= config.MAX_CLIENTS:
                        try:
                            sock.close()
                        finally:
                            self.on_log(f"Rejecting {addr}: max clients reached")
                        continue
                threading.Thread(target=self._handle_client, args=(sock, addr), daemon=True).start()
        except Exception as e:
            if not self._stop.is_set():
                self.on_log(f"Accept loop error: {e!r}")

    def _handle_client(self, sock: socket.socket, addr):
        try:
            hdr, payload = self._recv_packet(sock)
            if hdr.get("type") != "key":
                raise RuntimeError("Handshake: expected key from client")
            client_pub = x25519.X25519PublicKey.from_public_bytes(payload)

            my_pub = self._pub.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            self._send_packet(sock, {"type": "key", "content_len": len(my_pub)}, my_pub)

            shared = self._priv.exchange(client_pub)
            key = sha256(shared)

            hdr, payload = self._recv_packet(sock)
            if hdr.get("type") != "hello":
                raise RuntimeError("Handshake: expected hello from client")
            if hdr.get("v", config.PROTOCOL_VERSION) != config.PROTOCOL_VERSION:
                raise RuntimeError("Protocol version mismatch")
            auth_hex = hdr.get("auth_hex")
            if not auth_hex or bytes.fromhex(auth_hex) != self._auth_tag(key):
                raise RuntimeError("Peer authentication failed")

            nonce = bytes.fromhex(hdr["nonce_hex"])
            digest = bytes.fromhex(hdr["digest_hex"])
            name_json = self._decrypt_with(key, nonce, payload, digest, hdr)
            user = json.loads(name_json.decode("utf-8")).get("name") or f"{addr[0]}:{addr[1]}"

            base = f"{addr[0]}:{addr[1]}"
            display = f"{base} {user}" if user else base
            with self._clients_lock:
                self.clients[sock] = {"addr": addr, "key": key, "name": user, "display": display}
            self.on_log(f"Client joined: {display}")
            self._broadcast_members()

            while not self._stop.is_set():
                hdr, payload = self._recv_packet(sock)
                if hdr.get("v", config.PROTOCOL_VERSION) != config.PROTOCOL_VERSION:
                    self.on_log(f"Protocol version mismatch from {display}: {hdr.get('v')}")
                    continue
                self._process_packet(sock, hdr, payload)

        except Exception as e:
            self.on_log(f"Client handler error {addr}: {e!r}")
        finally:
            try:
                sock.close()
            except Exception as e:
                self.on_log(f"Error closing socket {addr}: {e!r}")
            with self._clients_lock:
                if sock in self.clients:
                    left = self.clients.pop(sock)
                    self.on_log(f"Client left: {left['display']}")
                    self._broadcast_members()

    def _process_packet(self, sock: socket.socket, hdr: dict, payload: bytes):
        with self._clients_lock:
            info = self.clients.get(sock)
            if not info:
                return
            key = info["key"]
            display = info["display"]
        t = hdr.get("type")

        if t == "msg":
            nonce = bytes.fromhex(hdr["nonce_hex"])
            digest = bytes.fromhex(hdr["digest_hex"])
            plain = self._decrypt_with(key, nonce, payload, digest, hdr)
            sender = display
            try:
                text = plain.decode("utf-8")
            except UnicodeDecodeError as e:
                self.on_log(f"Decode error from {sender}: {e!r}, raw: {plain[:100]!r}")
                text = plain.decode("utf-8", errors="replace")
            self.on_message(sender, text)
            self._broadcast_text(sender, plain, exclude=sock)

        elif t == "file":
            nonce = bytes.fromhex(hdr["nonce_hex"])
            digest = bytes.fromhex(hdr["digest_hex"])
            data = self._decrypt_with(key, nonce, payload, digest, hdr)
            fname = hdr.get("filename", "received.bin")
            sender = display

            try:
                save_path = _save_file_safely(data, fname, prefix="host_received_from")
                self.on_log(f"Host received file from {sender}: {fname} ({len(data)} bytes), saved to {save_path}")
            except Exception as e:
                self.on_log(f"Host save received file error: {e!r}")

            self._broadcast_file(sender=sender, data=data, filename=fname, exclude=sock)

        elif t == "key":
            self.on_log("Extra key packet ignored (host).")

        elif t == "hello":
            pass

        else:
            self.on_log(f"Unknown packet type from {display}: {t}")

    def _broadcast_text(self, sender: str, plaintext: bytes, exclude: Optional[socket.socket] = None):
        with self._clients_lock:
            clients_copy = list(self.clients.items())

        for s, inf in clients_copy:
            if s is exclude:
                continue
            key = inf["key"]
            base_header = {"type": "msg", "sender": sender}
            n, c, d = self._encrypt_with(key, plaintext, base_header)
            hdr = {
                "type": "msg",
                "sender": sender,
                "nonce_hex": n.hex(),
                "digest_hex": d.hex(),
                "content_len": len(c),
            }
            try:
                self._send_packet(s, hdr, c)
            except Exception as e:
                self.on_log(f"Broadcast text failed to {inf['display']}: {e!r}")

    def _broadcast_file(self, sender: str, data: bytes, filename: str, exclude: Optional[socket.socket] = None):
        with self._clients_lock:
            clients_copy = list(self.clients.items())

        for s, inf in clients_copy:
            if s is exclude:
                continue
            key = inf["key"]
            base_header = {"type": "file", "sender": sender, "filename": filename}
            n, c, d = self._encrypt_with(key, data, base_header)
            hdr = {
                "type": "file",
                "sender": sender,
                "filename": filename,
                "nonce_hex": n.hex(),
                "digest_hex": d.hex(),
                "content_len": len(c),
            }
            try:
                self._send_packet(s, hdr, c)
            except Exception as e:
                self.on_log(f"Broadcast file failed to {inf['display']}: {e!r}")

    def _current_member_list(self) -> List[str]:
        members = []
        if self.host_addr:
            members.append(f"{self.host_addr[0]}:{self.host_addr[1]} Host")
        with self._clients_lock:
            members.extend([v["display"] for v in self.clients.values()])
        return members

    def _notify_members_to_ui(self):
        self.on_members(self._current_member_list())

    def _broadcast_members(self):
        members = self._current_member_list()
        self.on_members(members)
        payload = json.dumps(members).encode("utf-8")

        with self._clients_lock:
            clients_copy = list(self.clients.items())

        for s, inf in clients_copy:
            key = inf["key"]
            n, c, d = self._encrypt_with(key, payload, {"type": "members", "sender": "host"})
            hdr = {
                "type": "members",
                "sender": "host",
                "nonce_hex": n.hex(),
                "digest_hex": d.hex(),
                "content_len": len(c),
            }
            try:
                self._send_packet(s, hdr, c)
            except Exception as e:
                self.on_log(f"Broadcast members failed to {inf['display']}: {e!r}")

    def close(self):
        self._stop.set()
        try:
            if self.conn:
                self.conn.close()
        except Exception as e:
            self.on_log(f"Error closing client connection: {e!r}")
        finally:
            self.conn = None
            self.shared_key = None

        try:
            with self._clients_lock:
                clients_copy = list(self.clients.keys())
                self.clients.clear()
            for s in clients_copy:
                try:
                    s.close()
                except Exception as e:
                    self.on_log(f"Error closing client socket: {e!r}")
        except Exception as e:
            self.on_log(f"Error clearing clients: {e!r}")

        try:
            if self.server_sock:
                try:
                    self.server_sock.shutdown(socket.SHUT_RDWR)
                except Exception:
                    pass
                self.server_sock.close()
        except Exception as e:
            self.on_log(f"Error closing server socket: {e!r}")
        finally:
            self.server_sock = None
            self.host_addr = None
            if self._srv_thread and self._srv_thread.is_alive():
                self._srv_thread.join(timeout=1.0)
            self._srv_thread = None

        self.on_state("CLOSED")
