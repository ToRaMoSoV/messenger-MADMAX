import sys

from PyQt6.QtWidgets import QApplication

from app.ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
    self.setStyleSheet("""
    QMainWindow {
        background-image: url(1.png);
        background-position: center;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }
""")


if __name__ == "__main__":
    main()
