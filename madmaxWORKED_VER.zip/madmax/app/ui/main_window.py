import os

from PyQt6.QtWidgets import (
    QWidget,
    QMainWindow,
    QVBoxLayout,
    QHBoxLayout,
    QTextEdit,
    QLineEdit,
    QPushButton,
    QLabel,
    QListWidget,
    QFileDialog,
    QSpinBox,
    QTabWidget,
    QFormLayout,
    QGroupBox,
    QMessageBox,
    QInputDialog,
)

from app.socket_module.net import PeerNode, validate_ip, validate_port
from app.db_module import orm
from app.db_module.edb import encrypt_db, decrypt_db

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Messenger MADMAX")
        self.resize(1024, 680)

        self.node = PeerNode()
        self.node.on_log = self.log
        self.node.on_message = self.on_incoming_text
        self.node.on_file_saved = self.on_incoming_file
        self.node.on_state = self.on_state
        self.node.on_members = self.on_members

        self.my_name = "Me"
        self.room_name = "Room"
        self.current_peer = "peer"
        self._db_password = ""
        self.db_ext = ".enc"

        try:
            orm.init_db()
        except Exception as e:
            QMessageBox.critical(self, "Database error", f"Failed to initialize database: {e!r}")
            self.log(f"Database initialization failed: {e!r}")

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self._init_chat_tab()
        self._init_settings_tab()
        self._load_history()

    def closeEvent(self, event):
        """Закрывает окно и корректно останавливает узел."""
        try:
            self.node.close()
        except Exception:
            pass
        event.accept()

    def _init_chat_tab(self):
        w = QWidget()
        root = QVBoxLayout(w)

        status_line = QHBoxLayout()
        self.lbl_state = QLabel("IDLE")
        self.lbl_host_info = QLabel("")
        btn_host = QPushButton("Create Room (Host)")
        btn_host.clicked.connect(self.on_host)
        self.in_room = QLineEdit(self.room_name)
        self.in_room.setPlaceholderText("Room name")
        self.in_my_name = QLineEdit(self.my_name)
        self.in_my_name.setPlaceholderText("Your name")

        self.in_ip = QLineEdit()
        self.in_ip.setPlaceholderText("Server IP")
        self.in_port = QSpinBox()
        self.in_port.setRange(1, 65535)
        self.in_port.setValue(55555)
        btn_connect = QPushButton("Join Room")
        btn_connect.clicked.connect(self.on_connect)

        status_line.addWidget(QLabel("State:"))
        status_line.addWidget(self.lbl_state, 1)
        status_line.addWidget(self.lbl_host_info, 2)
        status_line.addWidget(QLabel("Room:")); status_line.addWidget(self.in_room)
        status_line.addWidget(QLabel("Name:")); status_line.addWidget(self.in_my_name)
        status_line.addWidget(btn_host)
        status_line.addWidget(QLabel("Server IP:")); status_line.addWidget(self.in_ip)
        status_line.addWidget(QLabel("Port:")); status_line.addWidget(self.in_port)
        status_line.addWidget(btn_connect)

        body = QHBoxLayout()
        left = QVBoxLayout(); right = QVBoxLayout()

        self.members = QListWidget()
        self.members.setMaximumWidth(240)
        left.addWidget(QLabel("Room members:")); left.addWidget(self.members, 1)

        self.msg_list = QListWidget()
        self.msg_in = QLineEdit()
        self.msg_in.setPlaceholderText("Type message...")
        self.msg_in.returnPressed.connect(self.on_send_text)
        btn_send = QPushButton("Send")
        btn_send.clicked.connect(self.on_send_text)
        btn_file = QPushButton("Send File")
        btn_file.clicked.connect(self.on_send_file)

        bottom = QHBoxLayout()
        bottom.addWidget(self.msg_in, 1)
        bottom.addWidget(btn_send)
        bottom.addWidget(btn_file)

        right.addWidget(self.msg_list, 1)
        right.addLayout(bottom)

        body.addLayout(left, 0)
        body.addLayout(right, 1)

        root.addLayout(status_line)
        root.addLayout(body, 1)

        self.tabs.addTab(w, "Chat")

    def _init_settings_tab(self):
        w = QWidget()
        root = QVBoxLayout(w)

        db_box = QGroupBox("Database & Crypto")
        form = QFormLayout(db_box)
        self.lbl_db_mode = QLabel("DB key: auto (rotates daily)")
        btn_set_pwd = QPushButton("Set DB password"); btn_set_pwd.clicked.connect(self.on_set_password)
        self.lbl_ext = QLabel(f"Encrypted ext: {self.db_ext}")
        btn_set_ext = QPushButton("Change encrypted file extension"); btn_set_ext.clicked.connect(self.on_set_ext)
        btn_enc_db = QPushButton("Encrypt DB now (AES-256-CBC)"); btn_enc_db.clicked.connect(self.on_encrypt_db)
        btn_imp_db = QPushButton("Import/Decrypt DB"); btn_imp_db.clicked.connect(self.on_import_db)
        form.addRow(self.lbl_db_mode, btn_set_pwd); form.addRow(self.lbl_ext, btn_set_ext)
        form.addRow(QLabel(" ")); form.addRow(btn_enc_db, btn_imp_db)

        c_box = QGroupBox("Contacts")
        cform = QFormLayout(c_box)
        self.in_c_name = QLineEdit()
        self.in_c_ip = QLineEdit()
        self.in_c_port = QSpinBox()
        self.in_c_port.setRange(1, 65535)
        self.in_c_port.setValue(55555)
        btn_add_c = QPushButton("Add contact")
        btn_add_c.clicked.connect(self.on_add_contact)
        self.list_contacts = QListWidget()
        self._refresh_contacts()
        cform.addRow("Name:", self.in_c_name)
        cform.addRow("IP:", self.in_c_ip)
        cform.addRow("Port:", self.in_c_port)
        cform.addRow(btn_add_c)
        cform.addRow(QLabel("Saved:"), self.list_contacts)

        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)

        root.addWidget(db_box)
        root.addWidget(c_box, 1)
        root.addWidget(QLabel("Log:"))
        root.addWidget(self.log_view, 2)

        self.tabs.addTab(w, "Settings")

    def on_host(self):
        self.room_name = self.in_room.text().strip() or "Room"
        self.my_name = self.in_my_name.text().strip() or "Me"
        self.node.my_name = self.my_name
        self.node.room_name = self.room_name
        ip, port = self.node.start_host("0.0.0.0", 0)
        self.lbl_host_info.setText(f"Your IP: {ip}    Port: {port}")

    def on_connect(self):
        self.my_name = self.in_my_name.text().strip() or "Me"
        self.node.my_name = self.my_name

        ip = self.in_ip.text().strip()
        port = int(self.in_port.value())

        if not ip:
            QMessageBox.warning(self, "Invalid input", "IP address cannot be empty")
            return

        if not validate_ip(ip):
            QMessageBox.warning(self, "Invalid input", f"Invalid IP address: {ip}")
            return

        if not validate_port(port):
            QMessageBox.warning(self, "Invalid input", f"Invalid port: {port}")
            return

        try:
            self.node.connect_to(ip, port)
            self.log(f"Joined room at {ip}:{port} as {self.my_name}")
        except Exception as e:
            QMessageBox.critical(self, "Join failed", repr(e))
            self.log(f"Join failed: {e!r}")

    def on_send_text(self):
        text = self.msg_in.text().strip()
        if not text:
            return
        try:
            self.node.send_text(text)
            self._add_chat(self.my_name, text)
            try:
                orm.add_message(self.room_name, "out", text)
            except Exception as e:
                self.log(f"Failed to save message to database: {e!r}")
            self.msg_in.clear()
        except Exception as e:
            self.log(f"Send failed: {e!r}")

    def on_send_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select file to send")
        if not path:
            return
        try:
            self.node.send_file(path)
            self.log(f"Sent file: {path}")
        except Exception as e:
            self.log(f"Send file failed: {e!r}")

    def on_encrypt_db(self):
        """Шифрует локальную базу SQLite."""
        password = self._db_password or None
        try:
            out_path = encrypt_db(password, self.db_ext)
            self.log(f"DB encrypted -> {out_path}")
            QMessageBox.information(self, "DB", f"Encrypted to {out_path}")
        finally:
            if password:
                password = None

    def on_import_db(self):
        """Расшифровывает файл и восстанавливает chat.db."""
        enc_path, _ = QFileDialog.getOpenFileName(self, "Select encrypted DB file")
        if not enc_path:
            return
        try:
            password = self._db_password or None
            restore = decrypt_db(password, enc_path, restore_as="chat.db")
            self.log(f"DB decrypted -> {restore}")
            QMessageBox.information(self, "DB", "Decrypted and restored as chat.db")
        except Exception as e:
            QMessageBox.critical(self, "Decrypt failed", repr(e))
            self.log(f"Decrypt failed: {e!r}")

    def on_incoming_text(self, sender: str, text: str):
        self._add_chat(sender, text)
        try:
            orm.add_message(self.room_name, "in", f"{sender}: {text}")
        except Exception as e:
            self.log(f"Failed to save incoming message to database: {e!r}")

    def on_incoming_file(self, path: str):
        self._add_chat("peer", f"[file saved: {os.path.basename(path)}]")
        self.log(f"File received: {path}")

    def on_state(self, s: str):
        self.lbl_state.setText(s)

    def on_members(self, members: list):
        self.members.clear()
        for m in members:
            self.members.addItem(m)

    def log(self, msg: str):
        self.log_view.append(msg)

    def _add_chat(self, who: str, text: str):
        self.msg_list.addItem(f"{who}: {text}")
        self.msg_list.scrollToBottom()

    def _load_history(self):
        for (_id, peer, direction, content, ts) in orm.last_messages(200)[::-1]:
            who = "me" if direction == "out" else "peer"
            self._add_chat(who, content)

    def on_add_contact(self):
        name = self.in_c_name.text().strip() or "peer"
        ip = self.in_c_ip.text().strip()
        port = int(self.in_c_port.value())

        if not ip:
            QMessageBox.warning(self, "Invalid input", "IP address cannot be empty")
            return

        if not validate_ip(ip):
            QMessageBox.warning(self, "Invalid input", f"Invalid IP address: {ip}")
            return

        if not validate_port(port):
            QMessageBox.warning(self, "Invalid input", f"Invalid port: {port}")
            return

        try:
            orm.add_contact(name, ip, port)
            self.in_c_name.clear()
            self.in_c_ip.clear()
        except Exception as e:
            QMessageBox.critical(self, "Database error", f"Failed to add contact: {e!r}")
            self.log(f"Add contact failed: {e!r}")
            return
        self._refresh_contacts()

    def _refresh_contacts(self):
        self.list_contacts.clear()
        for (_id, name, ip, port) in orm.list_contacts():
            self.list_contacts.addItem(f"{name}  {ip}:{port}")
            
    def on_set_password(self):
        """Устанавливает или сбрасывает пароль шифрования БД."""
        pwd, ok = QInputDialog.getText(
            self, "Set password", "Enter new DB password:",
            echo=QLineEdit.EchoMode.Password
        )
        if ok:
            new_password = pwd.strip()
            if self._db_password:
                self._db_password = ""
            self._db_password = new_password
            if self._db_password:
                self.lbl_db_mode.setText("DB key: password-based (SHA-256)")
                self.log("DB password set manually.")
            else:
                self.lbl_db_mode.setText("DB key: auto (rotates daily)")
                self.log("DB password cleared (auto mode).")

    def on_set_ext(self):
        ext, ok = QInputDialog.getText(
            self, "Set extension", "Enter new encrypted file extension (e.g., .enc):"
        )
        if ok:
            ext = ext.strip()
            if not ext.startswith("."):
                ext = "." + ext
            self.db_ext = ext
            self.lbl_ext.setText(f"Encrypted ext: {ext}")
            self.log(f"DB extension changed to {ext}")
