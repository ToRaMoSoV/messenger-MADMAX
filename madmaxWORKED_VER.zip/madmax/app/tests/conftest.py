import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import config


@pytest.fixture(scope="session")
def temp_paths(tmp_path_factory):
    base = tmp_path_factory.mktemp("madmax_test")
    downloads = base / "downloads"
    downloads.mkdir()
    meta = base / ".meta"
    meta.mkdir()
    db_file = base / "chat.db"
    yield {"base": base, "downloads": downloads, "meta": meta, "db": db_file}
    shutil.rmtree(base, ignore_errors=True)


@pytest.fixture(autouse=True)
def patch_config(temp_paths, monkeypatch):
    monkeypatch.setattr(config, "DOWNLOAD_DIR", temp_paths["downloads"])
    monkeypatch.setattr(config, "META_DIR", temp_paths["meta"])
    monkeypatch.setattr(config, "DB_PATH", temp_paths["db"])
    if config.DB_PATH.exists():
        config.DB_PATH.unlink()
    config.DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    config.META_DIR.mkdir(parents=True, exist_ok=True)
    for f in config.DOWNLOAD_DIR.iterdir():
        f.unlink()
    yield
