from app.db_module import orm


def test_contacts_and_messages_roundtrip():
    orm.init_db()
    orm.add_contact("nill", "127.0.0.1", 5555)
    contacts = orm.list_contacts()
    assert contacts and contacts[0][1] == "nill"

    orm.add_message("room", "out", "hello")
    msgs = orm.last_messages(1)
    assert msgs and msgs[0][2] == "out" and "hello" in msgs[0][3]
