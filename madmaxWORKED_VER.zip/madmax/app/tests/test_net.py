import threading
import time
from queue import Queue
from pathlib import Path

import pytest

from app import config
from app.socket_module.net import PeerNode, validate_ip, validate_port


def test_validate_ip_and_port():
    assert validate_ip("127.0.0.1")
    assert not validate_ip("999.1.1.1")
    assert validate_port(5555)
    assert not validate_port(70000)


def test_handshake_and_message():
    psk = "test-psk"
    host = PeerNode(pre_shared_secret=psk)
    client = PeerNode(pre_shared_secret=psk)

    received = Queue()
    done = threading.Event()

    def on_host_msg(sender, msg):
        received.put((sender, msg))
        done.set()

    host.on_message = on_host_msg

    ip, port = host.start_host("127.0.0.1", 0)
    client.connect_to(ip, port)

    client.send_text("hello-world")

    assert done.wait(timeout=2.0), "Host did not receive message in time"
    sender, msg = received.get_nowait()
    assert "hello-world" in msg

    host.close()
    client.close()


def test_file_transfer(tmp_path):
    psk = "file-psk"
    host = PeerNode(pre_shared_secret=psk)
    client = PeerNode(pre_shared_secret=psk)

    logs = []
    host.on_log = lambda m: logs.append(f"host:{m}")
    client.on_log = lambda m: logs.append(f"client:{m}")

    ip, port = host.start_host("127.0.0.1", 0)
    client.connect_to(ip, port)

    deadline = time.time() + 3.0
    while time.time() < deadline and len(host.clients) == 0:
        time.sleep(0.05)
    assert len(host.clients) == 1, f"Client not registered: logs={logs}"

    src = tmp_path / "sample.txt"
    src.write_text("payload", encoding="utf-8")

    host.send_file(str(src))

    deadline = time.time() + 5.0
    saved_file = None
    while time.time() < deadline and not saved_file:
        for f in list(config.DOWNLOAD_DIR.glob("received*")) + list(config.DOWNLOAD_DIR.glob("host_received*")):
            saved_file = f
            break
        time.sleep(0.05)

    assert saved_file and saved_file.read_text(encoding="utf-8") == "payload", f"logs={logs}"
    host.close()
    client.close()


def test_psk_mismatch_rejected():
    host = PeerNode(pre_shared_secret="psk-a")
    bad_client = PeerNode(pre_shared_secret="psk-b")

    ip, port = host.start_host("127.0.0.1", 0)
    bad_client.connect_to(ip, port)
    time.sleep(0.2)
    assert len(host.clients) == 0

    host.close()
    bad_client.close()
