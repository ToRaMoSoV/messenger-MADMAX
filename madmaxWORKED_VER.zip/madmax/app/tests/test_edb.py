import os
from pathlib import Path

import pytest

from app.db_module import edb


def test_encrypt_decrypt_roundtrip(temp_paths, monkeypatch):
    db_path = temp_paths["db"]
    data = b"hello-db"
    db_path.write_bytes(data)

    out = edb.encrypt_db(password="secret", out_ext=".enc")
    assert Path(out).exists()

    restored = edb.decrypt_db(password="secret", enc_path=out, restore_as=str(db_path))
    assert Path(restored).read_bytes() == data


def test_decrypt_wrong_password_fails(temp_paths):
    db_path = temp_paths["db"]
    db_path.write_bytes(b"data")
    out = edb.encrypt_db(password="right", out_ext=".enc")

    with pytest.raises(ValueError):
        edb.decrypt_db(password="wrong", enc_path=out, restore_as=str(db_path))
