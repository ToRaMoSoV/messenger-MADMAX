import sys
from pathlib import Path

from app import config


def main() -> int:
    print("MADMAX health check")
    print(f"- protocol version: {config.PROTOCOL_VERSION}")
    print(f"- max header size: {config.MAX_HEADER_SIZE}")
    print(f"- max payload size: {config.MAX_PAYLOAD_SIZE}")
    print(f"- max clients: {config.MAX_CLIENTS}")

    paths = {
        "base": config.BASE_DIR,
        "downloads": config.DOWNLOAD_DIR,
        "db": config.DB_PATH,
        "meta": config.META_DIR,
    }
    for name, path in paths.items():
        p = Path(path)
        print(f"- {name}: {p}")
        if name in {"downloads", "meta"}:
            p.mkdir(parents=True, exist_ok=True)
            print(f"  exists: {p.exists()}  writable: {p.is_dir()}")

    psk = config.load_psk()
    print(f"- PSK set: {'yes' if psk else 'no'}")
    if not psk:
        print("  warning: MADMAX_PSK not set; peers will fail auth")
    return 0


if __name__ == "__main__":
    sys.exit(main())
